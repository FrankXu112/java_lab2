package lab2;

public class Driver {
	static Country country1;
	public static void main(String[] args) {
		country1  = new Country("Canada");
		country1.displayAllProvinces();
		country1.howManyHaveThisPopulation(4, 6);
	}
}
