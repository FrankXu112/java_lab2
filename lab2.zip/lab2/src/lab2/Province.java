package lab2;

/**
 * 
 * @author frankxu
 *
 */
public class Province {
	private String name;
	private String capital;
	private int populationInMillions;
	private static final String DEFAULT_PROVINCE = "Britsh Columbia";
	private static final String DEFAULT_CAPITAL = "Victoria";
	private static final int DEFAULT_POPULATION = 4;

	public Province() {
		this.populationInMillions = DEFAULT_POPULATION;
		this.name = DEFAULT_PROVINCE;
		this.capital = DEFAULT_CAPITAL;
	}

	public Province(String name, String capital, int populationInMillions) {
		if ((isValidPopulation(populationInMillions)) && (isValidProvince(name)) && (isValidCapitalCity(capital))) {
			this.populationInMillions = populationInMillions;
			this.name = name;
			this.capital = capital;

		} else {
			this.populationInMillions = DEFAULT_POPULATION;
			this.name = DEFAULT_PROVINCE;
			this.capital = DEFAULT_CAPITAL;
		}
	}

	public final boolean isValidProvince(String name) {
		String[] pro = new String[] { "Ontario", "Quebec", "Nova Scotia", "New Brunswick", "Manitoba",
				"British Columbia", "Prince Edward Island", "Saskatchewan", "Alberta", "Newfoundland and Labrador" };
		int i = 0;
		while (i < pro.length) {
			if (name.equals(pro[i])) {
				return true;
			}
			i++;
		}

		return false;
	}

	/**
	 * 
	 * @param name  set province name
	 */
	public final void setName(String name) {
		if (isValidProvince(name)) {
			this.name = name;
		}
	}

	public final boolean isValidCapitalCity(String capital) {
		String[] cap = new String[] { "Toronto", "Quebec City", "Halifax", "Fredericton", "Winnipeg", "	Victoria",
				"Charlottetown", "Regina", "Edmonton", "St. John's" };
		for (int j = 0; j < cap.length; j++) {
			if (capital.equals(cap[j])) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param capital set capital name
	 */
	public final void setCapital(String capital) {
		if (isValidCapitalCity(capital)) {
			this.capital = capital;
		}
	}

	public final boolean isValidPopulation(int populationInMillions) {
		if (populationInMillions >= 0 && populationInMillions <= 38) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param populationInMillions  set population in millions
	 */
	public final void setPopulationInMillions(int populationInMillions) {
		if (isValidPopulation(populationInMillions)) {
			this.populationInMillions = populationInMillions;
		}
	}

	/**
	 * return province name
	 * 
	 * @return return province name
	 */
	public String getName() {
		return name;
	}

	/**
	 * return capital name
	 * 
	 * @return return capital name
	 */
	public String getCapital() {
		return capital;
	}

	/**
	 * return population in millions
	 * 
	 * @return return population in millions
	 */
	public int getPopulationInMillions() {
		return populationInMillions;
	}
	
	/**
	 * print details of province object method
	 */
	public void printDetails() {
		System.out.println("The capital of " + getName() + " is " + getCapital() + ", and the population is "
				+ getPopulationInMillions());
	}

	@Override
	public String toString() {
		return "The capital of " + getName() + " is " + getCapital() + ", and the population is "
				+ getPopulationInMillions();
	}
}
