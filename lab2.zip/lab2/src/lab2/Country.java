package lab2;
/**
 * 
 * @author frankxu
 *
 */
public class Country {
	private String name;
	private Province[] pro;
	/**
	 * constructor for country class
	 * @param name name as class country's name
	 */
	public Country(String name) {
		this.name = name;
		
		pro = new Province[10];
		pro[0] = new Province("Ontario", "Toronto", 13);
		pro[1] = new Province("Quebec", "Quebec City", 8);
		pro[2] = new Province("Nova Scotia", "Halifax", 1);
		pro[3] = new Province("New Brunswick", "Fredericton", 1);
		pro[4] = new Province("Manitoba", "Winnipeg", 1);
		pro[5] = new Province("British Columbia", "Victoria", 4);	
		pro[6] = new Province("Prince Edward Island", "Charlottetown", 0);
		pro[7] = new Province("Saskatchewan", "Regina", 1);
		pro[8] = new Province("Alberta", "Edmonton", 4);
		pro[9] = new Province("Newfoundland and Labrador", "St. John's", 0);	
	}
	
	/**
	 * display all the provinces in country
	 */
	public void displayAllProvinces() {
		for(Province pro : pro) {
			pro.printDetails();
		}
	}
	
	/**
	 * display how many provinces in this range of population
	 * @param min min as minimum population you want to include
	 * @param max max as maximum population you want to include
	 */
	public void howManyHaveThisPopulation(int min, int max) {
		int count  = 0;
		for(Province pro : pro) {
			int pop = pro.getPopulationInMillions();
			if(pop >= min && pop <= max) {
				count += 1;
			}
		}
		if(count == 0) {
			System.out.println("There is no province with population in this range.");
		}
		else if(count == 1) {
			System.out.println("There is " + count + " province with population in this range.");
		}
		else {
			System.out.println("There are " + count + " provinces with population in this range.");
		}
		
	}
	
	/**
	 * return county's name
	 * @return return country's name
	 */
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "country " + this.getName() + "has 10 provinces.";
	}
}

